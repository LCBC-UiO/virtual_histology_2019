Shiny_cortical_trajectories

Description: Plots Trajectories of cortical thickness and thickening/thinning throughout the lifespan. 

Notes/possible improvements. 
1) The color changes by factor order not by order of selection 
2) Maybe in text 


sv-psi-36-173

Hi,
 
I am Didac, from the LCBC Center in the department of psychology.


I would like to install cytoscape https://cytoscape.org/download.html software, a tool to visualize gene ontology structures. 
Can you install it or give me the permissions to install it?

Thank you very much in advance,
D�dac
