### Shiny - GammStats ###
# ----------------------------------#
# 1) Select Desire stats
# 2) Display stat as ggseg
# 3) Display stats as col graph


###### loading data ######
# .......................#
packages <- c("shiny", "dplyr", "magrittr", "ggplot2", "tidyr", "stringi", "scales", "devtools")
newlib <- "C:/kant/sv-psi-u1/didacvp/pc/Dokumenter/R/win-library/3.4"
if (setdiff(newlib, .libPaths()) > 0) {.libPaths(c(newlib, .libPaths()))}
if (length(setdiff(packages, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(packages, rownames(installed.packages())), INSTALL_opts = c('--no-lock'))  
}
lapply(packages, require, character.only = T)
if (!"ggseg" %in% rownames(installed.packages())) {devtools::install_github("LCBC-UiO/ggseg", build_vignettes = F)}
require(ggseg)
wdir <- '//lagringshotell/sv-psi/LCBC/Users/Didac/Baycrest/ShinyReport'
outdir <-"Data" 
setwd(file.path(wdir, outdir))
load("gamm.stats.Rda")
load("varnames.Rda")

######## settting up everything ########
# .....................................#

stat <- names(gamm.stats)[-1]
gamm.stats %<>% separate(regions, c("label", "tmp")) %>% 
                mutate(label = paste0("lh_", label))

ggseg_brain <- ggseg()
ggseg_brain$data %<>%  left_join(., gamm.stats)


####### main script ####
# .....................#


ui <- fluidPage(
  fluidRow(titlePanel("GAMM model statistics"),
           column(6,
           selectInput("variable", "Select statistic of interest:", stat, multiple = FALSE))),
  fluidRow(plotOutput("plot.geo")),
  fluidRow(plotOutput("plot.bars"))
)


server <- function(input, output, session) {
  
  output$plot.geo <- renderPlot({
      gp <- ggseg(atlas = ggseg_brain$data,  
                  hemisphere = "left", 
                  mapping = aes(fill = get(input$variable)), 
                  color = "black") +
        scale_fill_gradient2("stat",
                             low = "blue", 
                             high = "red")
      return(gp)  
    })

  output$plot.bars <- renderPlot({
    ggplot(data = gamm.stats, mapping = aes(x = label, y = get(input$variable), group = label, fill = get(input$variable))) +
      geom_hline(yintercept = 0, linetype = 4) +
      geom_col() +
      theme(axis.text.x=element_text(angle = -45, hjust = 0, size = 10))+
      scale_y_continuous(name="stat") +
      scale_fill_gradient2("stat",
                           low = "blue", 
                           high = "red")
  })
  
}

shinyApp(ui, server)